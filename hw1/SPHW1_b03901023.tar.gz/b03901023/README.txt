Thank you TA!!!!
